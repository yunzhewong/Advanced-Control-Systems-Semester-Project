name = 'sinusoidRejection.png';
modelprint
print('-smodelprint', '-dpng', name, '-r600')